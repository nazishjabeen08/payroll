package com.cg.controller;

import java.sql.SQLException;

import com.cg.beans.Employee;
import com.cg.service.PayrollServices;

public class EmployeeController {
	
	private PayrollServices payService;
	
	@RequestMapping(value= "/emp/add", method = RequestMethod.POST)
	public String insertEmployee(@ModelAttribute("emp") Employee e)
	{
		
		if(e.getEmploeeId()== 0){
			//new person, add it
			( this.payService).insertEmployee(e);
		}
		return "/employees";
		
	}
	
	
}
