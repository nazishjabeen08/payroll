package com.cg.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.beans.Employee;
import com.cg.exceptions.PayrollServicesDownException;


public interface PayrollDAOServices {
	
	int insertEmployee(Employee employee)throws SQLException;
	boolean updateEmployee(Employee employee)throws SQLException;
	boolean deleteEmployee(int employeeId)throws SQLException;
	Employee getEmployee(int employeeId)throws SQLException;
	List<Employee>getAllEmployees()throws SQLException;
}
