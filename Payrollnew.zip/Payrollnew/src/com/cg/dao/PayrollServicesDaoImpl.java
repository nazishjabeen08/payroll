package com.cg.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.beans.Employee;
import com.cg.exceptions.PayrollServicesDownException;

@Repository("Payrolldao")
public class PayrollServicesDaoImpl implements PayrollDAOServices{
	
	@Autowired
	private SessionFactory sessionfactory;

	@Override
	public int insertEmployee(Employee employee) throws SQLException {
		
		 sessionfactory.getCurrentSession().save(employee);
		return 0;
	}

	@Override
	public boolean updateEmployee(Employee employee) throws SQLException {
		
		sessionfactory.getCurrentSession().update(employee);
		return false;
	}

	@Override
	public boolean deleteEmployee(int employeeId) throws SQLException {
		
		  sessionfactory.getCurrentSession().createQuery("DELETE FROM Employee WHERE employeeId = employeeId").executeUpdate();
		return false;
	}

	@Override
	public Employee getEmployee(int employeeId) throws SQLException {
		
		
		  return (Employee) sessionfactory.getCurrentSession().get(Employee.class, employeeId);
	
	}

	@Override
	public List<Employee> getAllEmployees() throws SQLException {
		
		 return (List<Employee>) sessionfactory.getCurrentSession().createCriteria(Employee.class).list();
	}

	
}
