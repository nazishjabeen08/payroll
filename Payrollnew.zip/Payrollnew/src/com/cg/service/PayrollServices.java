package com.cg.service;
import java.util.List;

import com.cg.beans.Employee;
import com.cg.exceptions.EmployeeDetailsNotFoundException;
import com.cg.exceptions.PayrollServicesDownException;
import com.cg.beans.*;


public interface PayrollServices {
	
	
	double calculateEmployeeNetSalary(int employeeId) throws EmployeeDetailsNotFoundException,PayrollServicesDownException;
	Employee getEmployeeDetails(int employeeid)throws EmployeeDetailsNotFoundException,PayrollServicesDownException;
	List<Employee> getAllEmployeeDetails()throws PayrollServicesDownException;
	void delete(int empId);
	void saveOrUpdate(Employee e);
}