package com.cg.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Employee;
import com.cg.beans.Salary;
import com.cg.dao.PayrollDAOServices;
import com.cg.exceptions.EmployeeDetailsNotFoundException;
import com.cg.exceptions.PayrollServicesDownException;

@Service("PayrollService")
public class PayrollServicesImpl implements PayrollServices {
	
	
	@Autowired
	private PayrollDAOServices payrollDao;
	@Override
	public double calculateEmployeeNetSalary(int employeeId)
			throws EmployeeDetailsNotFoundException,
			PayrollServicesDownException {
		
		 Salary s=new Salary();
		double bs=s.getBasicSalary();
		double hra =  0.4*bs;
		double ta = 0.2*bs;
		double da = 0.25*bs;
		double companyPf = 3480;
		double employeePf=3480;
		double grossSalary = hra+ta+da+bs+companyPf+employeePf;
		double annualSalary=grossSalary*12;
		double tax = 0;
		if(annualSalary>=0 && annualSalary<=250000)
			tax=0;
				else if(annualSalary>250000 && annualSalary<=500000)
					tax=0.05*(bs-250000);
						else if(annualSalary>500000 && annualSalary<=1000000)
							tax=0.20*(annualSalary-500000)+0.05*250000;
								else if(annualSalary>1000000)
									tax=30*(bs-1000000)+0.20*500000+0.05*250000;
		
		
		double netSalary=annualSalary-tax-companyPf-employeePf;
		
		return netSalary;
	}

	@Override
	public Employee getEmployeeDetails(int employeeid)
			throws EmployeeDetailsNotFoundException,
			PayrollServicesDownException {
		 try {
			return payrollDao.getEmployee(employeeid);
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
		
	
	}

	@Override
	public List<Employee> getAllEmployeeDetails()
			throws PayrollServicesDownException {
		try {
			return payrollDao.getAllEmployees();
		} catch (SQLException e) {
			
			e.printStackTrace();
			return null;
		}
		
				
	}


}
