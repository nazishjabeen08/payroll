package com.cg.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Salary {
	
	private double basicSalary;
	private double hra,ta,da;
	private double companyPf=3480, employeePf=3480;
	private double grossSalary,monthlyTax,netSalary;
	
	public double getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}
	

}
